# Ste-Foy AdBlock

Bloqueur de publicités et de traqueurs : une extension de navigateur (dossier `extension`) et une option pour bloquer les pubs sur tout le réseau de la maison (dossier `adguard-home`).

Aucune donnée n'est collectée ni envoyée.

## Contenu
- `extension/` : l'extension, qui bloque environ 189 000 domaines publicitaires.
- `adguard-home/` : blocage des pubs pour toute la maison (télé, consoles, téléphones sur le Wi-Fi).

## Installer l'extension

### Chrome ou Edge
1. Dézippez cette archive et gardez le dossier à un endroit stable (ne le supprimez pas ensuite).
2. Ouvrez `chrome://extensions` (Edge : `edge://extensions`).
3. Activez **Mode développeur**.
4. Cliquez sur **Charger l'extension non empaquetée** et choisissez le dossier `extension`.
5. Épinglez l'icône **Ste-Foy AdBlock** dans la barre d'outils.

### Firefox
1. Ouvrez `about:debugging#/runtime/this-firefox`.
2. Cliquez sur **Charger un module complémentaire temporaire**.
3. Choisissez `extension/manifest.json`.
4. Attention : l'installation disparaît à la fermeture de Firefox et doit être refaite.

## Utiliser
Cliquez sur l'icône pour voir le compteur de requêtes bloquées et activer ou désactiver le blocage.

## Bloquer les pubs sur tous les appareils de la maison
Voir `adguard-home/README.md` (nécessite une machine toujours allumée, avec Docker).

Sur téléphone, sans rien installer : DNS privé `dns.adguard-dns.com` (Android : Paramètres > Réseau > DNS privé). Sur iPhone : application AdGuard ou NextDNS.

## Mettre à jour la liste de blocage
1. Téléchargez `https://adguardteam.github.io/HostlistsRegistry/assets/filter_1.txt` dans `extension/lists/adguard-dns.txt`.
2. Dans `extension/`, lancez `python3 gen_rules.py`.
3. Rechargez l'extension.

## Limites
- Une extension ne protège que le navigateur, pas les applications mobiles ni les télés.
- Les pubs intégrées dans les vidéos (YouTube, streaming) ne sont pas bloquées.
- Certains sites détectent les bloqueurs de publicité.
- Testée dans Chromium (blocage vérifié) ; non testée dans Firefox.
